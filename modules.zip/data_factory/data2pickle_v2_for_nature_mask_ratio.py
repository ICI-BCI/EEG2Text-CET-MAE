from transformers import BartTokenizer
import codecs
import os
import numpy as np
import h5py
import data_loading_helpers_modified as dh
from glob import glob
from tqdm import tqdm
import pickle
import torch
from copy import deepcopy



if __name__ == "__main__":
    version = 'v2'
    eeg_type = "GD"  # gaze duration (GD)
    max_len = 58
    dim = 105
    bands = ['_t1', '_t2', '_a1', '_a2', '_b1', '_b2', '_g1', '_g2']
    task_names = ["task2-NR-2.0","task3-TSR-2.0"]
    is_add_CLS_token = False

    print("load tokenizer......")
    tokenizer = BartTokenizer.from_pretrained('../models/huggingface/bart-large')

    all_num_word_tokens_has_fixation = 0
    all_num_word_tokens_with_mask = 0
    all_num_word_tokens_all = 0

    for task_name in task_names:
        print(f'start processing ZuCo-{version} {task_name}...')

        # load files
        input_mat_files_dir = f"../zuco_dataset/{task_name}/Matlab_files"
        mat_files = glob(os.path.join(input_mat_files_dir, '*.mat'))
        mat_files = sorted(mat_files)

        num_word_tokens_has_fixation = 0
        num_word_tokens_with_mask = 0
        num_word_tokens_all = 0

        dataset_dict = {}

        for mat_file in tqdm(mat_files):

            subject = os.path.basename(mat_file).split('_')[0].replace('results', '').strip()
            if subject != 'YMH':
                assert subject not in dataset_dict
                dataset_dict[subject] = []

                f = h5py.File(mat_file, 'r')
                sentence_data = f['sentenceData']

                # sent level eeg
                # mean_t1 = np.squeeze(f[sentence_data['mean_t1'][0][0]][()])
                mean_t1_objs = sentence_data['mean_t1']
                mean_t2_objs = sentence_data['mean_t2']
                mean_a1_objs = sentence_data['mean_a1']
                mean_a2_objs = sentence_data['mean_a2']
                mean_b1_objs = sentence_data['mean_b1']
                mean_b2_objs = sentence_data['mean_b2']
                mean_g1_objs = sentence_data['mean_g1']
                mean_g2_objs = sentence_data['mean_g2']

                rawData = sentence_data['rawData']
                contentData = sentence_data['content']
                omissionR = sentence_data['omissionRate']
                wordData = sentence_data['word']

                for idx in range(len(rawData)):
                    # get sentence string
                    obj_reference_content = contentData[idx][0]
                    sent_string = dh.load_matlab_string(f[obj_reference_content])

                    sent_obj = {'content': sent_string}

                    sent_obj['word'] = []

                    # get word level data
                    word_data, word_tokens_all, word_tokens_has_fixation, word_tokens_with_mask = dh.extract_word_level_data(
                        f, f[wordData[idx][0]])

                    if word_data == {}:
                        print(f'missing sent: subj:{subject} content:{sent_string}, append None')
                        dataset_dict[subject].append(None)
                        continue
                    elif len(word_tokens_all) == 0:
                        print(f'no word level features: subj:{subject} content:{sent_string}, append None')
                        dataset_dict[subject].append(None)
                        continue


                    sent_obj['word_tokens_has_fixation'] = word_tokens_has_fixation
                    sent_obj['word_tokens_with_mask'] = word_tokens_with_mask
                    sent_obj['word_tokens_all'] = word_tokens_all

                    num_word_tokens_has_fixation += len(word_tokens_has_fixation)
                    num_word_tokens_with_mask += len(word_tokens_with_mask)
                    num_word_tokens_all += len(word_tokens_all)

        print(task_name,"有效word：", num_word_tokens_has_fixation)
        print(task_name,"mask word:", num_word_tokens_with_mask)
        print(task_name,"总word:", num_word_tokens_all)
        print(task_name,"天然掩码率：",(num_word_tokens_with_mask/num_word_tokens_all)*100)

        all_num_word_tokens_has_fixation+=num_word_tokens_has_fixation
        all_num_word_tokens_with_mask+=num_word_tokens_with_mask
        all_num_word_tokens_all +=num_word_tokens_all

    print(all_num_word_tokens_has_fixation)
    print(all_num_word_tokens_with_mask)
    print(all_num_word_tokens_all)