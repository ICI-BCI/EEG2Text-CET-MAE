import os
import numpy as np
import torch
import pickle
import scipy.io as io
from glob import glob
from transformers import BartTokenizer
from tqdm import tqdm
import codecs
from copy import deepcopy

if __name__ == "__main__":
    version = 'v1'
    eeg_type = "GD"  # gaze duration (GD)
    max_len = 58
    dim = 105
    # theta1 (4–6Hz), theta2 (6.5–8 Hz)
    # alpha1 (8.5–10 Hz), alpha2 (10.5–13 Hz)
    # beta1 (13.5–18Hz), beta2 (18.5–30 Hz)
    # gamma1 (30.5–40 Hz) and gamma2 (40–49.5 Hz)
    bands = ['_t1', '_t2', '_a1', '_a2', '_b1', '_b2', '_g1', '_g2']
    task_names = ["task1-SR", "task2-NR","task3-TSR"]
    # task_names = ["task1-SR"]
    print("load tokenizer......")
    tokenizer = BartTokenizer.from_pretrained('../models/huggingface/bart-large')

    all_num_word_tokens_has_fixation = 0
    all_num_word_tokens_with_mask = 0
    all_num_word_tokens_all = 0

    for task_name in task_names:
        print(f'start processing ZuCo-{version} {task_name}...')

        # load files
        input_mat_files_dir = f"../zuco_dataset/{task_name}/Matlab_files"
        mat_files = glob(os.path.join(input_mat_files_dir, '*.mat'))
        mat_files = sorted(mat_files)

        dataset_dict = {}

        num_word_tokens_has_fixation = 0
        num_word_tokens_with_mask = 0
        num_word_tokens_all = 0

        # 每个人的mat文件
        for mat_file in tqdm(mat_files):

            subject_name = os.path.basename(mat_file).split('_')[0].replace('results', '').strip()
            dataset_dict[subject_name] = []
            matdata = io.loadmat(mat_file, squeeze_me=True, struct_as_record=False)['sentenceData']

            # 每个句子
            for sent in matdata:
                word_data = sent.word
                if not isinstance(word_data, float):
                    # sentence level:
                    sent_obj = {'content': sent.content}
                    sent_obj['sentence_level_EEG'] = {'mean_t1': sent.mean_t1, 'mean_t2': sent.mean_t2,
                                                      'mean_a1': sent.mean_a1, 'mean_a2': sent.mean_a2,
                                                      'mean_b1': sent.mean_b1, 'mean_b2': sent.mean_b2,
                                                      'mean_g1': sent.mean_g1, 'mean_g2': sent.mean_g2}
                    # word level:
                    sent_obj['word'] = []

                    word_tokens_has_fixation = []
                    word_tokens_with_mask = []
                    word_tokens_all = []

                    # 句子中的每个单词
                    for word in word_data:
                        word_obj = {'content': word.content}
                        word_tokens_all.append(word.content)
                        word_obj['nFixations'] = word.nFixations
                        if word.nFixations > 0:
                            sent_obj['word'].append(word_obj)
                            word_tokens_has_fixation.append(word.content)
                            # word_tokens_with_mask.append(word.content)
                        else:
                            word_tokens_with_mask.append('[MASK]')
                            continue

                    sent_obj['word_tokens_has_fixation'] = word_tokens_has_fixation
                    sent_obj['word_tokens_with_mask'] = word_tokens_with_mask
                    sent_obj['word_tokens_all'] = word_tokens_all

                    num_word_tokens_has_fixation += len(word_tokens_has_fixation)
                    num_word_tokens_with_mask += len(word_tokens_with_mask)
                    num_word_tokens_all += len(word_tokens_all)

                    dataset_dict[subject_name].append(sent_obj)
                else:
                    dataset_dict[subject_name].append(None)
                    continue
        print(task_name,"有效word：", num_word_tokens_has_fixation)
        print(task_name,"mask word:", num_word_tokens_with_mask)
        print(task_name,"总word:", num_word_tokens_all)
        print(task_name,"天然掩码率：",(num_word_tokens_with_mask/num_word_tokens_all)*100)

        all_num_word_tokens_has_fixation+=num_word_tokens_has_fixation
        all_num_word_tokens_with_mask+=num_word_tokens_with_mask
        all_num_word_tokens_all +=num_word_tokens_all

    print(all_num_word_tokens_has_fixation)
    print(all_num_word_tokens_with_mask)
    print(all_num_word_tokens_all)
